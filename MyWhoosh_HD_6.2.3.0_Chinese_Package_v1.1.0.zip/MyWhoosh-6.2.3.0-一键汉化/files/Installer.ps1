﻿param([ValidateSet('Install','Restore','Check')][string]$Mode='Install')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$data=Join-Path $env:LOCALAPPDATA 'MyWhooshChinesePatch'
$log=Join-Path $data ('Logs\'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+$Mode+'.txt')
$transcribing=$false
$mutex=$null;$locked=$false
try {
 $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
 $mutex=New-Object Threading.Mutex($false,('Local\MyWhooshChinesePatch-'+$sid))
 try{$locked=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true}
 if(-not $locked){throw '另一个汉化安装或恢复程序正在运行，请等待它完成。'}
 [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($log))|Out-Null
 Start-Transcript -LiteralPath $log -Force|Out-Null;$transcribing=$true
 Import-Module (Join-Path $PSScriptRoot 'MwPatchCore.psm1') -Force -DisableNameChecking
 $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $packages=@(Get-AppxPackage -Name MyWhooshTechnologyService.MyWhoosh -ErrorAction Stop)
 if($packages.Count -ne 1){throw '当前用户未检测到微软商店版 MyWhoosh HD。请使用玩游戏的同一 Windows 账户运行，勿改用其他管理员账户。'}
 $package=$packages[0]
 if($package.PackageFamilyName -ne $manifest.packageFamilyName){throw '游戏安装类型不匹配。'}
 $context=[pscustomobject]@{Version=$package.Version.ToString();GameRoot=$package.InstallLocation;SavedRoot=(Join-Path $env:LOCALAPPDATA ('Packages\'+$package.PackageFamilyName+'\LocalCache\Local\MyWhoosh\Saved'));DataRoot=$data}
 Write-Host ('游戏版本：'+$context.Version)
 Write-Host ('补丁目录：'+(Get-MwTarget $context))
 if((Get-MwHash (Join-Path $PSScriptRoot 'CoursePatch.dll')) -ne $manifest.courseDllSha256){throw '课程组件校验失败。'}
 Add-Type -Path (Join-Path $PSScriptRoot 'CoursePatch.dll')
 if($Mode -eq 'Restore') {
  Assert-MwClosed
  $courses=[MwCourses]::Run($context.SavedRoot,$data,'',$true)
  $categories=[MwCourses]::Categories($context.SavedRoot,$data,'',$true)
  $r=Restore-MwEnglish $context $manifest
  Write-Host ('恢复课程文字：'+$courses.Changed+' 份；跳过已变更或不存在课程：'+$courses.Skipped+' 份。')
  Write-Host '界面补丁已停用。请重新启动游戏。';exit 0
 }
 Assert-MwCompatibility $context $manifest
 Assert-MwPayload (Join-Path $PSScriptRoot 'MyWhooshChinese_P.pak') $manifest
 $dictionary=Join-Path $PSScriptRoot 'courses.json'
 if((Get-MwHash $dictionary) -ne $manifest.coursesSha256){throw '课程字典校验失败。'}
 $categoryDictionary=Join-Path $PSScriptRoot 'categories.json'
 if((Get-MwHash $categoryDictionary) -ne $manifest.categoriesSha256){throw '分类字典校验失败。'}
 if($Mode -eq 'Install'){
  $r=Install-MwPatch $context (Join-Path $PSScriptRoot 'MyWhooshChinese_P.pak') $manifest
  $cache=Join-Path $data 'Recovery';[IO.Directory]::CreateDirectory($cache)|Out-Null
  foreach($name in @('Installer.ps1','MwPatchCore.psm1','manifest.json','CoursePatch.dll')){ $src=Join-Path $PSScriptRoot $name;$dst=Join-Path $cache $name;if([IO.Path]::GetFullPath($src) -ne [IO.Path]::GetFullPath($dst)){[IO.File]::WriteAllBytes($dst,[IO.File]::ReadAllBytes($src))} }
  $courses=[MwCourses]::Run($context.SavedRoot,$data,$dictionary,$false)
  $categories=[MwCourses]::Categories($context.SavedRoot,$data,$categoryDictionary,$false)
  Write-Host '界面补丁：已写入并通过校验；是否在游戏中加载仍需打开游戏确认。'
  Write-Host ('课程缓存：扫描 '+$courses.Scanned+' 份，匹配 '+$courses.Matched+' 份，本次更新 '+$courses.Changed+' 份，未匹配 '+$courses.Skipped+' 份。')
  if($courses.Matched -eq 0){Write-Host '课程汉化未完成：请先打开游戏进入训练课程列表、退出游戏，再运行本安装程序。';exit 2}
  Write-Host '课程汉化已应用。介绍含自动译文和校对要点，并保留英文原文。'
 }else{
  $target=Get-MwTarget $context
  if(-not(Test-Path -LiteralPath $target) -or (Get-MwHash $target) -ne $manifest.patchSha256){throw '界面补丁未安装或文件不同。'}
  Write-Host '界面补丁文件校验通过。仅此检查无法证明游戏已加载汉化。'
  $courses=[MwCourses]::Inspect($context.SavedRoot,$dictionary)
  Write-Host ('课程检查：扫描 '+$courses.Scanned+' 份，已匹配本版中文 '+$courses.Matched+' 份，未匹配 '+$courses.Skipped+' 份。')
  if($courses.Matched -eq 0){Write-Host '课程汉化未检测到。先进入游戏训练列表生成缓存，退出后重新安装。';exit 2}
  Write-Host '如仍为英文，请完全退出游戏再启动，确认运行的是微软商店版 HD 6.2.3.0，并保留诊断日志。'
 }
 Write-Host ('诊断日志：'+$log)
}catch{
 Write-Host ('操作未完成：'+$_.Exception.Message)
 Write-Host '可能已完成部分操作，请保留日志，勿将此结果视为全部安装成功。'
 Write-Host ('诊断日志：'+$log)
 exit 1
}finally{if($transcribing){Stop-Transcript|Out-Null};if($locked){$mutex.ReleaseMutex()};if($mutex){$mutex.Dispose()}}
