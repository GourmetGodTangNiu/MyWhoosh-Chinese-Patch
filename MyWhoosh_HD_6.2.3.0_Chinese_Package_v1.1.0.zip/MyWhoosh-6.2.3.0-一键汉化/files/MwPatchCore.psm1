﻿Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
function Get-MwHash([string]$Path) {
    $stream=[IO.File]::OpenRead($Path);$sha=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','') }
    finally { $stream.Dispose();$sha.Dispose() }
}
function Assert-MwClosed {
    if(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^MyWhoosh(?:HD)?(?:-(?:Win64|WinGDK|UWP64)-Shipping)?$' }){throw '请先完全退出 MyWhoosh，再重新运行安装程序。'}
}
function Assert-MwCompatibility($Context,$Manifest) {
    if([version]$Context.Version -ne [version]$Manifest.gameVersion){throw ('仅支持微软商店版 MyWhoosh HD '+$Manifest.gameVersion+'；当前版本为 '+$Context.Version+'。未修改游戏。')}
    $original=Join-Path $Context.GameRoot 'MyWhoosh\Content\Paks\pakchunk0-Windows.pak'
    if(-not (Test-Path -LiteralPath $original)){throw '无法读取当前游戏资源，未安装补丁。'}
    if((Get-MwHash $original) -ne $Manifest.gamePakSha256){throw '游戏资源与本补丁对应的版本不一致，已停止安装。'}
}
function Assert-MwPayload([string]$Payload,$Manifest) {
    if(-not(Test-Path -LiteralPath $Payload)){throw '安装包不完整：缺少补丁文件。'}
    if((Get-MwHash $Payload) -ne $Manifest.patchSha256){throw '补丁文件校验失败，请重新获取完整安装包。'}
}
function Get-MwTarget($Context) {
    $saved=[IO.Path]::GetFullPath($Context.SavedRoot).TrimEnd('\')+'\'
    $target=[IO.Path]::GetFullPath((Join-Path $saved 'Paks\MyWhooshChinese_P.pak'))
    if(-not $target.StartsWith($saved,[StringComparison]::OrdinalIgnoreCase)){throw '补丁目标路径无效。'}
    return $target
}
function New-MwBackup($Context,[string]$Target,[string]$Label) {
    $folder=Join-Path $Context.DataRoot 'Backups'
    [IO.Directory]::CreateDirectory($folder) | Out-Null
    $file=Join-Path $folder ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+$Label+'-'+[guid]::NewGuid().ToString('N')+'.pak')
    [IO.File]::WriteAllBytes($file,[IO.File]::ReadAllBytes($Target))
    if((Get-MwHash $file) -ne (Get-MwHash $Target)){throw '备份校验失败，未替换现有补丁。'}
    return $file
}
function Install-MwPatch($Context,[string]$Payload,$Manifest) {
    Assert-MwClosed
    Assert-MwCompatibility $Context $Manifest
    Assert-MwPayload $Payload $Manifest
    $target=Get-MwTarget $Context
    $known=@($Manifest.patchSha256)+@($Manifest.knownPreviousPatchHashes)
    $backup=$null
    if(Test-Path -LiteralPath $target){
        $current=Get-MwHash $target
        if($current -eq $Manifest.patchSha256){return [pscustomobject]@{Status='AlreadyInstalled';Backup=$null;Target=$target}}
        if($current -notin $known){throw '检测到其他来源的同名补丁，已停止；不会覆盖它。'}
        $backup=New-MwBackup $Context $target 'before-install'
    }
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
    $temp=$target+'.installing-'+[guid]::NewGuid().ToString('N')
    $replaceBackup=$target+'.previous-'+[guid]::NewGuid().ToString('N')
    $changed=$false
    try {
        [IO.File]::WriteAllBytes($temp,[IO.File]::ReadAllBytes($Payload))
        if((Get-MwHash $temp) -ne $Manifest.patchSha256){throw '写入校验失败。'}
        Assert-MwClosed
        if(Test-Path -LiteralPath $target){[IO.File]::Move($target,$replaceBackup)}
        [IO.File]::Move($temp,$target)
        $changed=$true
        if((Get-MwHash $target) -ne $Manifest.patchSha256){throw '安装后校验失败。'}
        return [pscustomobject]@{Status='Installed';Backup=$backup;Target=$target}
    } catch {
        if($backup){[IO.File]::WriteAllBytes($target,[IO.File]::ReadAllBytes($backup))}
        elseif($changed -and (Test-Path -LiteralPath $target)){[IO.File]::Delete($target)}
        throw
    } finally {
        if(Test-Path -LiteralPath $temp){[IO.File]::Delete($temp)}
        if(Test-Path -LiteralPath $replaceBackup){[IO.File]::Delete($replaceBackup)}
    }
}
function Restore-MwEnglish($Context,$Manifest) {
    Assert-MwClosed
    $target=Get-MwTarget $Context
    if(-not(Test-Path -LiteralPath $target)){return [pscustomobject]@{Status='AlreadyEnglish';Backup=$null;Target=$target}}
    $known=@($Manifest.patchSha256)+@($Manifest.knownPreviousPatchHashes)
    $hash=Get-MwHash $target
    if($hash -notin $known){throw '检测到其他来源的同名补丁，已停止；不会删除它。'}
    $backup=New-MwBackup $Context $target 'disabled'
    Assert-MwClosed
    if((Get-MwHash $target) -ne $hash){throw '补丁在操作期间发生变化，已停止。'}
    [IO.File]::Delete($target)
    return [pscustomobject]@{Status='RestoredEnglish';Backup=$backup;Target=$target}
}
Export-ModuleMember -Function Get-MwHash,Assert-MwClosed,Assert-MwCompatibility,Assert-MwPayload,Get-MwTarget,Install-MwPatch,Restore-MwEnglish
